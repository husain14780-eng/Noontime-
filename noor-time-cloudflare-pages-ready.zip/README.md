# Noor & Time — Supabase COD Store

This is a small e-commerce starter built with plain HTML/CSS/JS and Supabase.

Included:
- Public storefront for Attars and Watches
- Cart
- Cash on Delivery checkout
- Secure owner login with Supabase Auth
- Owner-only product add/edit/delete
- Product image uploads through Supabase Storage
- Owner orders dashboard
- Live new-order notification through Supabase Realtime
- Server-side price/stock calculation through a Supabase RPC
- Row Level Security policies

## 1. Create the Supabase project

1. Create a Supabase project.
2. Open SQL Editor.
3. Paste all of `supabase-schema.sql`.
4. Run it.

## 2. Create the owner account

1. Open Authentication → Users.
2. Add a user with the owner's email and password.
3. Copy that user's UUID.
4. Back in SQL Editor run:

```sql
insert into public.profiles (id, role)
values ('YOUR-AUTH-USER-UUID-HERE', 'owner')
on conflict (id) do update set role = 'owner';
```

There is intentionally no public signup button.

## 3. Create image storage

1. Open Storage.
2. Create a bucket named `product-images`.
3. Make it Public.
4. The SQL file already contains the upload/update/delete policies.

## 4. Put your Supabase keys in the website

Open `config.js` and replace:

```js
window.SUPABASE_URL = "YOUR_SUPABASE_PROJECT_URL";
window.SUPABASE_ANON_KEY = "YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY";
```

Use the project URL and the browser-safe publishable/anon key from Project Settings → API.

Never put a `service_role` key in `config.js` or any browser file.

## 5. Test locally

Because browsers can restrict local files, use a tiny local web server.

With Python installed:

```bash
python -m http.server 5500
```

Then open:

http://localhost:5500

Or use VS Code + Live Server.

## 6. First test

1. Open the website.
2. Click Owner.
3. Sign in.
4. Add an Attar.
5. Upload an image.
6. Set a price and stock.
7. Sign out.
8. Add the product to cart.
9. Place a COD order using a test phone/address.
10. Sign in again to Owner.
11. The order should be visible.
12. Keeping the owner dashboard open while placing another order should show a live notification.

## 7. Free hosting

The frontend is static, so you can host these files on a free static host or GitHub Pages. Supabase remains the backend.

Do not use your Supabase `service_role` secret in static frontend hosting.

## Notes

- Old order items keep their product name and price even if the product is later deleted.
- Stock is reduced by the secure `place_order` function.
- Customers cannot query the orders table through the public API.
- The owner is the only account with product-management and order-reading permissions.
